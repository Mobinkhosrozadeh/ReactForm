
import './App.css';
import SubmitForm from './SubmitForm';

function App() {
  return (
    <div className="App">
      <SubmitForm>

      </SubmitForm>
    </div>
  );
}

export default App;
